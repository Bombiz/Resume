// asst3v1.cpp    ALGORITHM DESIGN   
// array of strings
#include <iostream>
#include <iomanip>
#include <string>
#include <stdio.h>
#pragma warning(disable:4996)

//for setw function to format output
using namespace std;
const int LMAX = 100;       //maximum number of name strings in array
const int NMAX = 10;        //maximum size of each name string
int LSIZE = 20;		       //number of actual name strings in array

void OutList(char[][NMAX], int[], char[], char[], char[]);  /*outputs arraies: nam and wght, 
															column headings, and table title */
void PutMenu();
char GetChoice(bool);
void CopyList(char[][NMAX], int[], char[][NMAX], int[]);
void InSort();
void DoSort(char, char[][NMAX], int[]);
void SelectSort();
void ShellSort();


int main()
  {
   char choice; 
   char loop = 'y';
   char hd1[6] = "NAMES";
   char hd2[7] = "WEIGHT";
   char hd3[21] = "UNSORTED ARRAY DATA:";
   bool OneSortDone   = false;

					    //array of name strings
   char nam[LMAX][NMAX] = { "wendy", "ellen", "freddy", "tom", "susan", 
	                         "dick", "harry", "aloysius", "zelda", "sammy",
							 "mary", "hortense", "georgie", "ada", "daisy", 
					    	 "paula", "alexander", "louis", "fiona", "bessie"  };			

						//array of weights corresponding to these names
   int wght[LMAX] = { 120, 115, 195, 235, 138, 177, 163, 150, 128, 142,
                       118, 134, 255, 140, 121, 108, 170, 225, 132, 148 };
   char WKnam[LMAX][NMAX]; 
   int  WKwght[LMAX];
   
   OutList(nam, wght, hd3, hd1, hd2 );

   while(toupper(loop) == 'Y')
   {
	   PutMenu();
	   choice = GetChoice( OneSortDone );
	   CopyList(nam, wght, WKnam, WKwght);
	   switch (choice)
	   {
	   case '1': 
		   InSort();
		   OneSortDone = true;
		   break;
	   case '2':
		   SelectSort();
		   OneSortDone = true;
		   break;
	   case '3':
		   ShellSort(); 
		   OneSortDone = true;
		   break;
	   case '4':
		   break;
	   }

	   if(choice == '4')
		   break;

   }

  if(choice == '4')
  {
	  cout << "I am The Search Transaction\n";
	  system("pause");
  }

 
   

   return 0;
}

   
/****************************************************************************
                      PRINT OUT THE UNSORTED ARRAY DATA            
****************************************************************************/
  
   
   void OutList(char name[][NMAX], int wight[], char ragrth[], char heading1[], char heading2[])
{
   cout << ragrth << endl << endl;
   cout << setw(12) << heading1 << setw(12) << heading2 << endl << endl;

   for(int j=0; j<LSIZE; j++)  //display name strings & corresponding weights
      cout << setw(12) << name[j] << setw(12) << wight[j]  << endl;

    cout << endl << endl;
	system ( "pause" );
}

/****************************************************************************
          1 - PUT UP MENU .... LET THE USER CHOOSE A SORT ALGORITHM            
****************************************************************************/
   void PutMenu()
   {
	   system("cls");

	   cout << "       Menu   \n\n";
	   cout <<"1 : INSERTION SORT \n";
	   cout <<"2 : SELECTION SORT \n";
	   cout <<"3 : SHELL     SORT \n";
	   cout <<"4 : SEARCH TRANSACTION (exit Menu)\n\n\n";
	   system ( "pause" );

   }
   char GetChoice(bool onesort)
   {
	   char h;
	   
	   printf("Enter Choice(Number): ");
	   cin >> h;

	   while( onesort == false && h >= '4' )
	   {    cout <<"Must sort Once:";
		    cin >> h;
	   }

	   while( h > '4' )
	   {    cout  << "Enter a Valid number:";
	        cin >> h;
	   }

	  return h;
   }

/****************************************************************************
          2 - COPY THE ARRAYS INTO WORK ARRAY i.e. don't clobber originals
****************************************************************************/
   void CopyList(char name[][NMAX], int weight[], char workname[][NMAX], int workwght[])
   {
	   for(int i=0; i<LSIZE; i++)
	   {strcpy(workname[i], name[i]);
	   workwght[i] = weight[i];
	   }
   }
/****************************************************************************
                    3 - SORT THE ARRAYS WITH RESPECT TO NAME            
****************************************************************************/
   void InSort()
   {
	   cout << "I am Insert\n";
	   system("pause");
   }
   void ShellSort()
   {
	   cout << "I am Shell\n";
	   system("pause");
   }
   void SelectSort()
   {
	   cout << "I am Select\n";
	   system("pause");
   }

/****************************************************************************
                        4 - PRINT THE SORTED ARRAYS            
****************************************************************************/

/****************************************************************************
                    5 - REPEAT STEPS 1-4 AS DESIRED
*****************************************************************************/

/****************************************************************************
                      6 - PROCESS THE INPUT SEARCH TRANSACTIONS            
****************************************************************************/