// asst3v1.cpp    ALGORITHM DESIGN   
// array of strings
#include <iostream>
#include <iomanip>
#include <string>
#include <stdio.h>
#pragma warning(disable:4996)

//for setw function to format output
using namespace std;
const int LMAX = 100;       //maximum number of name strings in array
const int NMAX = 10;        //maximum size of each name string
int LSIZE = 20;		       //number of actual name strings in array

void OutList(char[][NMAX], int[], char[], char[], char[]);  /*outputs arraies: nam and wght, 
															column headings, and table title */
void PutMenu();
char GetChoice(bool);
void CopyList(char[][NMAX], int[], char[][NMAX], int[]);
void InSort(char[][NMAX], int[]);
void DoSort(char, char[][NMAX], int[]);
void SelectSort(char[][NMAX], int[]);
int GetGaps(int[]);
void ShellSort(char[][NMAX], int[]);


int main()
  {
   char choice; // what choice the user has selected for menu loop
   char loop = 'y'; // is the user done with the sorting loop?
   char hd1[6] = "NAMES";
   char hd2[7] = "WEIGHT";
   char hd3[21] = "UNSORTED ARRAY DATA:";
   bool OneSortDone   = false;
					    //array of name strings
   char nam[LMAX][NMAX] = { "wendy", "ellen", "freddy", "tom", "susan", 
	                         "dick", "harry", "aloysius", "zelda", "sammy",
							 "mary", "hortense", "georgie", "ada", "daisy", 
					    	 "paula", "alexander", "louis", "fiona", "bessie"  };			

						//array of weights corresponding to these names
   int wght[LMAX] = { 120, 115, 195, 235, 138, 177, 163, 150, 128, 142,
                       118, 134, 255, 140, 121, 108, 170, 225, 132, 148 };
   char WKnam[LMAX][NMAX]; 
   int  WKwght[LMAX];
   
   OutList(nam, wght, hd3, hd1, hd2 );

   do
   {
	   PutMenu();
	   choice = GetChoice(OneSortDone);
	   CopyList(nam, wght, WKnam, WKwght);
	   switch (choice)
	   {
	   case '1': 
		   OutList(WKnam, WKwght, hd3, hd1, hd2 );
		   InSort(WKnam, WKwght);
		   OutList(WKnam, WKwght, hd3, hd1, hd2 );
		   OneSortDone = true;
		   break;
	   case '2':
		   OutList(WKnam, WKwght, hd3, hd1, hd2 );
		   SelectSort(WKnam, WKwght);
		   OutList(WKnam, WKwght, hd3, hd1, hd2 );
		   OneSortDone = true;
		   break;
	   case '3':
		   OutList(WKnam, WKwght, hd3, hd1, hd2 );
		   ShellSort(WKnam, WKwght); 
		   OutList(WKnam, WKwght, hd3, hd1, hd2 );
		   OneSortDone = true;
		   break;
	   case '4':
		   break;
	   }

	  if(choice == '4') 
		   if(OneSortDone == true)
			   break;

		   							  

   }
   while((toupper(loop) == 'Y') || (OneSortDone == false));

   loop='y';
   while(toupper(loop)=='Y')
   {
	   cout << "I am The Search Transaction\n";
	   loop = 'n';
	   system("pause");
   }


 
   

   return 0;
}

   
/****************************************************************************
                      PRINT OUT THE UNSORTED ARRAY DATA            
****************************************************************************/
  
   
   void OutList(char name[][NMAX], int wight[], char ragrth[], char heading1[], char heading2[])
{
   cout << ragrth << endl << endl;
   cout << setw(12) << heading1 << setw(12) << heading2 << endl << endl;

   for(int j=0; j<LSIZE; j++)  //display name strings & corresponding weights
      cout << setw(12) << name[j] << setw(12) << wight[j]  << endl;

    cout << endl << endl;
	system ( "pause" );
}

/****************************************************************************
          1 - PUT UP MENU .... LET THE USER CHOOSE A SORT ALGORITHM            
****************************************************************************/
   void PutMenu()
   {
	   system("cls");

	   cout << "       Menu   \n\n";
	   cout << "YOU MUST DO AT LEAST 1 SORT\n";
	   cout <<"1 : INSERTION SORT \n";
	   cout <<"2 : SELECTION SORT \n";
	   cout <<"3 : SHELL     SORT \n";
	   cout <<"4 : SEARCH TRANSACTION (exit Menu)\n\n\n";
	   system ( "pause" );

   }
   char GetChoice(bool onesort)
   {
	   char h;
	   
	   printf("Enter Choice(Number): ");
	   cin >> h;

	   while(onesort==false&&h>='4')
	   {    
		   cout <<"Must sort Once:";
		   cin >> h;
	   }

	   while(h>'4')
	   {   
		   cout  << "Enter a Valid number:";
	       cin >> h;
	   }

	  return h;
   }

/****************************************************************************
          2 - COPY THE ARRAYS INTO WORK ARRAY i.e. don't clobber originals
****************************************************************************/
   void CopyList(char name[][NMAX], int weight[], char workname[][NMAX], int workwght[])
   {
	   for(int i=0; i<LSIZE; i++)
	   {strcpy(workname[i], name[i]);
	   workwght[i] = weight[i];
	   }
   }
/****************************************************************************
                    3 - SORT THE ARRAYS WITH RESPECT TO NAME            
****************************************************************************/
   void InSort(char WKname[][NMAX], int WKweight[])
   {
	   int k = 1;
	   char y[200];
	   int w;
	   int i;
	   bool found;

	   system("cls");

	   

	   do
	   {
		   strcpy(y, WKname[k]);
		   w = WKweight[k];
		   found = false;
		   i = k - 1;
		   while(i>=0 && found == false)
		   {
			   if(strcmp(y, WKname[i]) == -1)
			   {
				   strcpy(WKname[i+1], WKname[i]);
				   WKweight[i+1] = WKweight[i];
				   i = i - 1;
			   }
			   else
				   found = true;
		   }

		   strcpy(WKname[i + 1], y);
		   WKweight[i+1] = w;
		   k = k + 1;
	   }while(k<=LSIZE-1);


   }
   void SelectSort(char WKname[][NMAX], int WKweight[])
   {
	   int i;         //size of array
	   char big[100]; // holds name
	   int n;         // holds number
	   int where = 0; //in the array
	   int j;         

	   i = LSIZE - 1; //get array size

	   do
	   {
		   strcpy(big, WKname[0]); //
		   n = WKweight[0];
		   where = 0;
		   j = 1;

		   do
		   {
			   while(strcmp(WKname[j], big) == 1)
			   {
				   strcpy(big, WKname[j]);
				   n = WKweight[j];
				   where = j;
			   }

			   j++;

		   }while(j<=i);

		   strcpy(WKname[where], WKname[i]);
		   WKweight[where] = WKweight[i];

		   strcpy(WKname[i], big);
		   WKweight[i] = n;

		   i=i-1;
	   }while(i>0);

	    
   }
   void ShellSort(char WKname[][NMAX], int WKweight[])
   {
	   int i, j, gap, h, k;
	   bool found;
	   char y[NMAX];
	   int gaplist[LMAX];
	   int numgaps;
	   numgaps = GetGaps(gaplist);
	   
	   i = numgaps - 1;

	   do
	   {
		   gap = gaplist[i];
		   j = gap;

		   do
		   {
			   strcpy(y, WKname[j]);
			   h = WKweight[j];
			   k = j - gap;
			   found = false;

			   while(k>=0 && !found)
			   {
				   if(strcmp(y, WKname[k]) == -1)
				   {
					   strcpy(WKname[k+gap], WKname[k]);
					   WKweight[k+gap] = WKweight[k];
					   k=k-gap;
				   }
				   else
					   found=true;
			   }

			   strcpy(WKname[k+gap], y);
			   WKweight[k+gap]=h;
			   j++;
		   }
		   while(j<=LSIZE-1);
		   i--;
	   }
	   while(i>=0);
   }


   int GetGaps(int gaps[])
   {
	   int gap = 1;
	   int pos = 0;
	   int numgaps;
	   int low=0;
	   int high = LSIZE-1;
	   while(gap<(high-low)+1)
	   {
		   gaps[pos]=gap;
		   gap=gap*3;
		   pos=pos+1;
		   //numgaps = pos - 1;
	   }

	   numgaps = pos - 1;
	   return numgaps;
   }

/****************************************************************************
                        4 - PRINT THE SORTED ARRAYS            
****************************************************************************/

/****************************************************************************
                    5 - REPEAT STEPS 1-4 AS DESIRED
*****************************************************************************/

/****************************************************************************
                      6 - PROCESS THE INPUT SEARCH TRANSACTIONS            
****************************************************************************/