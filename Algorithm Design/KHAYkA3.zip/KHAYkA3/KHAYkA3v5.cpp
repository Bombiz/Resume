/******************************* ID BLOCK ***************************************************** 
Due Date September 29, 2013
Software Designer: Kombiz Khayami
Course:  420-306-AB Fall 2013
Deliverable: Assignment #3 --- Sorting and Searching
Description:
This application sorts a list of names 'nam[]' and a list of body weights 'wght[]' with respect to the name 
useing 3 types of sorts(Selection, Insertion, and Shell).Before sorting it copies both arrays into 
2 Work arrays 'WKnam[]' and 'WKwght[]' to preserve the original data and allow for multiple sorts. 
After that, it will process a simple search transaction that reads in a name 'xnam[]' submitted by the user. 
If found application out puts postion of name, the corrosponding wehight, and the name whith its case intact. 
This program first out puts the full un-sorted list of names and weights then puts up a menu 
that has 4 options and asks the user to enter a choice. The first 3 options are the diffrent types of sorts 
and the last one(option 4) exits the menu and moves on to the search transaction.
Sorting is done useing the Work arrays. To get the gaps for Shell Sort a function called GetGaps is called.
The user is allowed to sort as many times as he wants before moveing on to the search trransaction. 
But he must sort once before moveing on.

/*************************************** PERLIMINARIES *****************************************/
#include <iostream>
#include <iomanip>            //for setw function to format output
#include <string>
#include <stdio.h>
#pragma warning(disable:4996) //ignor c-string function warnings
using namespace std;
const int LMAX = 100;         //maximum number of name strings in array
const int NMAX = 10;          //maximum size of each name string
int LSIZE = 20;		          //number of actual name strings in array

/*************************************** FUNCTION PROTOTYPES *****************************************/
void OutList(char[][NMAX], int[], char[], char[], char[]);  //out puts arraies to screen with headings and title
void PutMenu();                                             //out put the menu. has 4 options to chose from
char GetChoice(bool);										//get the users choice
void CopyList(char[][NMAX], int[], char[][NMAX], int[]);    //copy 2 arrays into 2 disposiable arrays
void InSort(char[][NMAX], int[]);
void SelectSort(char[][NMAX], int[]);						//preform selection sort on a array
void ShellSort(char[][NMAX], int[]);
int GetGaps(int[]);
void Search(char[][NMAX], int[]);							//the seach transaction
int Bsrch(char[][NMAX], char[]);							//search array useing binary search

/*************************************** MAIN BLOCK BEGINS *****************************************/
int main()
{   char choice;                           //choice the user has selected for menu loop
    char loop = 'y';                       // is the user done with searching?
    bool OneSortDone   = false;            //makes sure that the user did 1 sort
    char hd1[6] = "NAMES";                 //column heading for nam[]
    char hd2[7] = "WEIGHT";                //column heading for wght[]
    char hd3[21] = "UNSORTED ARRAY DATA:"; //table heading for unsorted array
	char hd4[19] = "SORTED ARRAY DATA:";   //table heading for sorted array
    char WKnam[LMAX][NMAX];                //to preserve the original data
    int  WKwght[LMAX];                     //to preserve the original data
	 				     //array of name strings
    char nam[LMAX][NMAX] = { "wendy", "ellen", "freddy", "tom", "susan", 
	                         "dick", "harry", "aloysius", "zelda", "sammy",
							 "mary", "hortense", "georgie", "ada", "daisy", 
					    	 "paula", "alexander", "louis", "fiona", "bessie"  };			

						//array of weights corresponding to these names
    int wght[LMAX] = { 120, 115, 195, 235, 138, 177, 163, 150, 128, 142,
                       118, 134, 255, 140, 121, 108, 170, 225, 132, 148 };
   
   
   
    OutList( nam, wght, hd3, hd1, hd2 );  //show user the original unsorted data

    do
    {    PutMenu();                         // puts up the menu 
	     choice = GetChoice( OneSortDone ); //what did the user chose?
	     switch ( choice )
	     {   case '1': 
		         system( "cls" );
		         CopyList( nam, wght, WKnam, WKwght );   //copys the original arrays into the 2 work arrays
				 OutList( WKnam, WKwght, hd4, hd1, hd2 );//show user the original unsorted data
		         InSort( WKnam, WKwght );                //sorts the 2 work arraies useing Insertion sort
		         OutList( WKnam, WKwght, hd4, hd1, hd2 );//show user the sorted data
		         OneSortDone = true;                     //the user has done at least one sort
		         break;
	        case '2':
				 system( "cls" );
		         CopyList( nam, wght, WKnam, WKwght );   //see case one comment
				 OutList( WKnam, WKwght, hd4, hd1, hd2 );//see case one comment
		         SelectSort( WKnam, WKwght );            //sorts the 2 work arraies useing Selection sort
		         OutList( WKnam, WKwght, hd4, hd1, hd2 );//see case one comment
		         OneSortDone = true;                     //see case one comment
		         break;
	        case '3':
				 system( "cls" );
		         CopyList( nam, wght, WKnam, WKwght );    //see case one comment
				 OutList( WKnam, WKwght, hd4, hd1, hd2 ); //see case one comment
		         ShellSort( WKnam, WKwght );              //sorts the 2 work arraies useing Shell sort
		         OutList( WKnam, WKwght, hd4, hd1, hd2);  //see case one comment
		         OneSortDone = true;                      //see case one comment
		         break;
	        case '4':                              
		         break;							 
	   }

    }
    while( choice != '4' || OneSortDone == false );//while user did wants to sort or did not sort at least once

   system( "cls" );

   while( toupper(loop) == 'Y' ) // while the user still wants to sort
   {   Search( WKnam, WKwght );  //peform search transaction
	   cout << "Search again?(Y/N):";
	   cin >> loop;
   }
   return 0;
}

/*************************************** FUNCTIONS *****************************************/
   
/****************************************************************************
OutList FUNCTION DEFINITION
outputs either the original arrays or the Work arrays along 
with 2 column headings, and table title. 
****************************************************************************/
void OutList(char string[][NMAX], int numbers[], char ragrth[], char heading1[], char heading2[])
{   cout << ragrth << endl << endl;
    cout << setw(12) << heading1 << setw(12) << heading2 << endl << endl;

    for( int j = 0; j < LSIZE; j++ )  //display name strings & corresponding weights
       cout << setw(12) << string[j] << setw(12) << numbers[j]  << endl;

    cout << endl << endl;
	system ( "pause" );
}
/****************************************************************************
PutMenu FUNCTION DEFINITION       
outputs the menu. Menu has the choices the user has along with their corrosponding number
****************************************************************************/
void PutMenu()
{   system( "cls" );

	cout << "       Menu   \n\n";
	cout << "YOU MUST SORT AT LEAST ONCE\n";
	cout << "1 : INSERTION SORT \n";
	cout << "2 : SELECTION SORT \n";
	cout << "3 : SHELL     SORT \n";
	cout << "4 : SEARCH TRANSACTION (exit Menu)\n\n";
}
/****************************************************************************
GetChoice FUNCTION DEFINITION
Gets the choice the user has selected. 
The user must sort once and is not allowed to enter a non-valid number
****************************************************************************/
char GetChoice(bool onesort)
{   char h; // users choice
	   
	cout << "Enter Choice(Number):";
	cin >> h;

	while( onesort == false && h >= '4' ) //while user hasn't sorted once and did not enter a valid choice
	{    cout <<"Must sort Once:";
		 cin >> h;
	}

	while( h > '4' )                     //while the user has sorted once but did not enter a valid choice
	{    cout  << "Enter a Valid choice:";
	     cin >> h;
	}

    return h;                            //returns users choice
}

/****************************************************************************
CopyList FUNCTION DEFINITION 
Copy arrays nam and wght into 2 work arrays for sorting.
This preserves the original data for subsequent sorting operations.
****************************************************************************/
void CopyList(char string[][NMAX], int numbers[], char othernm[][NMAX], int otherwg[]) 
{   for( int i = 0; i < LSIZE; i++ ) 
	{   strcpy( othernm[i], string[i] ); //copy the name into the work array
	    otherwg[i] = numbers[i];        //copy the weight into the work array
	}
}

   void InSort(char othernm[][NMAX], int otherwg[])
   {
	   int k = 1;
	   char y[200];
	   int w;
	   int i;
	   bool found;

	   system("cls");

	   do
	   {
		   strcpy(y, othernm[k]);
		   w = otherwg[k];
		   found = false;
		   i = k - 1;
		   while(i>=0 && found == false)
		   {
			   if(strcmp(y, othernm[i]) == -1)
			   {
				   strcpy(othernm[i+1], othernm[i]);
				   otherwg[i+1] = otherwg[i];
				   i = i - 1;
			   }
			   else
				   found = true;
		   }

		   strcpy(othernm[i + 1], y);
		   otherwg[i+1] = w;
		   k = k + 1;
	   }while(k<=LSIZE-1);


   }
/****************************************************************************
SelectSort FUNCTION DEFINITION
Sorts the name array(ascending) useing the Selection Sort methode. 
it sorts by selecting the first index(index 0) as big[] and compares it with every other element in the array. 
if a bigger value is found, it replaces it and saves the posistion of that value as 'where'. 
it keeps going until the end of the array and if 
no bigger value is found big[] swaps places whith that last element in the array, 
decreases the size of the array and makes the last element in the array the value of 'where'. 
   
****************************************************************************/
void SelectSort( char othernm[][NMAX], int otherwg[] )
{   int i;         //gets the size of the array
	char big[100]; //the current big number
	int n;         //saves the weight
    int where;     //posistion saver
    int j;         //index counter

	i = LSIZE - 1; //get size of array

	do
	{   strcpy( big, othernm[0] ); //hold on to the first name in the array
		n = otherwg[0];            //hold on to the first weight in the array
		where = 0;                 
		j = 1;                     //index starting position

		do
		{   if(strcmp(othernm[j], big) == 1) // if othernm[j] bigger then 'big'?
			{   strcpy( big, othernm[j] );      // update big to othernm[j]
				n = otherwg[j];                 // get weight lincked to big
				where = j;                     //save posistion swap took place in
			}

			j++;                   //increase index 

		}
		while( j <= i ); //while we have not reached the begging of the array

		strcpy( othernm[where], othernm[i] ); //
		otherwg[where] = otherwg[i];          // get weight lincked to big

		strcpy( othernm[i], big );            //
		otherwg[i] = n;                       // get weight lincked to big

		i=i-1;                                //reduce array size.
	}
	while( i > 0 );//repeate until we have reached the end of the aray 

	    
}
   void ShellSort(char othernm[][NMAX], int otherwg[])
   {
	   int i, j, gap, h, k;
	   bool found;
	   char y[NMAX];
	   int gaplist[LMAX];
	   int numgaps;
	   numgaps = GetGaps(gaplist);
	   
	   i = numgaps - 1;

	   do
	   {
		   gap = gaplist[i];
		   j = gap;

		   do
		   {
			   strcpy(y, othernm[j]);
			   h = otherwg[j];
			   k = j - gap;
			   found = false;

			   while(k>=0 && !found)
			   {
				   if(strcmp(y, othernm[k]) == -1)
				   {
					   strcpy(othernm[k+gap], othernm[k]);
					   otherwg[k+gap] = otherwg[k];
					   k=k-gap;
				   }
				   else
					   found=true;
			   }

			   strcpy(othernm[k+gap], y);
			   otherwg[k+gap]=h;
			   j++;
		   }
		   while(j<=LSIZE-1);
		   i--;
	   }
	   while(i>=0);
   }
int GetGaps(int gaps[])
{   int gap = 1;
	int pos = 0;
	int numgaps;
	int low=0;
	int high = LSIZE-1;

	while( gap < ( high - low ) + 1 )
	{   gaps[pos] = gap;
		gap = gap * 3;
	    pos = pos + 1;
	}

	numgaps = pos - 1;
	return numgaps;
}
/****************************************************************************

Bsrch FUNCTION DEFINITION
Searches through the name array for user entered name useing Binary Search.
(Compares the string beining searched with the half point of the array. 
If their equal then it returns the posistion of the half point. 
If its bigger then it cuts out the lower part of the array otherwise it cuts outs the upper part.
if it runs out of elements to search and the string is not found then it returns bsrch as -1.
note: half point is found by  adding the lowest and highest points of the array and dividing it by 2)  

****************************************************************************/
int Bsrch(char othernam[][NMAX], char name[])
{   int bsrch; //return value
	int low;  //lowest array point
    int high; //highest array point 
    int mid;  //half point
	   
	bsrch = -1; //initializ to not found
	low = 0;    //get the lowest point
	high = LSIZE - 1; //get the highest point
		
	while( low <= high )						       //while we still have elements to search
	{    mid = ( low + high ) / 2;                     // find the half point
		 if( strcmp( name, othernam[mid] ) == 0 )      //if name is found save it's posistion and exit loop 
		 {   bsrch = mid;                          
			 low = LSIZE;                          
		 }
		 else
		 {   if( strcmp( name, othernam[mid] ) == -1 ) //if the string is bigger then the half point
				 high = mid - 1;					   //cut off the upper part of the array
			 else                                      //if the string is bigger then the half point
				 low = mid + 1;                        //cut iff the lower part of the array
		 }
	}
		
	return bsrch; //return the position of the name
}
/****************************************************************************
Search FUNCTION DEFINITION 
Preforms the Saerch Transaction. Asks user to search for a name(Note it doesn't matter if the user 
enteres the name in upper and/or lower case). Then Calls Binary Search to Search for it. 
If name was found it outputsthe name, its posistion in the array, and the weight of that person.
****************************************************************************/
void Search(char othernam[][NMAX], int otherwg[])
{    int l;                                             //result from Bsrch 
     char xnam[100];                                    //name entered by user(used in searchtransaction)
	 char holder[100];                                  //holds user entered name whith cases intact.
        
      cout << "please enter a name to search(enter nothing to quit):";
	  cin >> xnam;
		                                                          
	  for(int count = 0; strlen(xnam) >= count; count++ ) 
	  {   holder[count]=xnam[count];                      //save name with cases intact
		  xnam[count] = tolower(xnam[count]);             // convert name to lowers case for searching    
	  }	  														  
		
	  l = Bsrch(othernam, xnam);                                    //Searches then name array for xnam

	  if( l >= 0 )                                                //was xnam found?
	      cout << holder << " was found a position " <<l+1<< " and her/his body weight is " <<otherwg[l]<<endl; 
	  else
		  cout << holder << " was not found\n";
}






		
