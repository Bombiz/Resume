// asst4v1.cpp    ALG306 
// parsing, text processing and numeric conversion
// this is an exercise in state-analysis and state-variable application design 
// data is supplied as an array of strings

#include <iostream>
#include <iomanip>             //for setw function to format output
using namespace std;

enum StateType { white, word, num, dble, expon };  
enum CharType { whsp, lett, expo, digit, plus, minus, point, quote, endstr }; 
CharType chtype;
StateType state; //current state of the application
char line[200], ch;
int length;
int wlen;
int i;
int k; //subscript indicating present position within the current line
int len;  

//*************FUNCTIONS*******************
//--------------STATE HANDLERS-------------------------
void WhiteState(); //reads in only white spaces and end strings(end of the line)
void WordState();//reads in everything that isn't a white space
void DoubleState();//reads in only digits 
void ExponentState();
void DigitState();
void ChartypeHandler(char);  //checks what type the char is
//-------------STATE TRANSITIONS----------------
//White State Transition
void WhitetoWord();
void WhitetoDigit();
void WhitetoDble();
//Word State Transition
void WordtoWhite();
//Number State Transitions
void DigittoWhite();
void DigittoDble();
void DigittoExponent();
//Double State Transitions
void DbletoWhite();
void DbletoExponent();
//Exponent State Transition
void ExponenttoWhite();

//********************MAIN BLOCK*****************************
int main()
   {
	const int LMAX = 200;		//maximum number of chars per line 
	const int NLINES = 10;		//maximum number of lines
	const int myLINES = 4;      // ACTUAL number of text data lines
	const int NDBLE = 10;		//maximum number of doubles
	const int NINT = 10;		//maximum number of integers
	const int WMAX = 10;		//maximum number of characters in a word
   
   //array of text lines i.e. the input data
   char tline[NLINES][LMAX] = {
   "  first 123 and now second -.1234 and you're needing this 123.456 plus one of these +123. too",
   "  ellen's favourites are 123.654E-2 eg exponent-form which can also be -54321E-03 or this +432e2",
   " I'll prefer numbers like fmt1-dec +.1234567e+05 or fmt2-dec -765.3245 or fmt1-int -837465 or ", 
   " even fmt2-int -19283746 which make us think of each state's behaviour for +3 or even .3471e7 states ", 
   };	

   //int length;
   //char line[LMAX], ch;
   //int k, len;

	// ARRAYS FOR RESULTS
	// double mydbls [NDBLE];
	// int myints [NINT];
	// int mywords[WMAX];
    
/****************************************************************************
                      PRINT OUT THE RAW TEXT LINES            
****************************************************************************/
	cout << "TEXT DATA LINES:" << endl << endl;
	cout << endl;
	for(int j=0; j<myLINES; j++)
	{   strcpy( line, tline[j]);
	    length=strlen(tline[j]); 
		cout <<  line  << endl;
		for(k=0; k<length;)   // statart going through the line
		{   
 			switch(state)
			{
				case white:
					WhiteState();           
					break;
				case word:
					WordState();
					break;
				case num:
					DigitState();
					break;
				case dble:
					DoubleState();
					break;
				case expon:
					ExponentState();
					break;
			}
			if (chtype == endstr)           //if we have reched the end of the line 
				break;                      //move on to the next line

			
		}
		printf("\n\n");
		state = white;    //assume each line begins with white state
		k = -1;           //go to/start at the begining of the line
		system("PAUSE");  //pause after each line parsed
		printf("\n");
	}
	cout<<endl<<endl;
	system("PAUSE");
   return 0;
   }

void ChartypeHandler(char ch)
{
	if (isspace(ch))
		chtype = whsp;
	else
	if (isalpha(ch))
		chtype = lett;
	else
	if (isdigit(ch))
		chtype = digit;




	switch (ch)
	{
	case '.':
		chtype = point;
		break;
	case '+':
		chtype = plus;
		break;
	case '-':
		chtype = minus;
		break;
	case '\'':
		chtype = quote;
		break;
	case '\0':
		chtype = endstr;
		break;
	}
}
void WhiteState() //changing the state
   {
	   while(state == white)   //while we are still in white state
	   {   ch = line[k++];  //move on to the next char
		   ChartypeHandler(ch);   //get the char type
		   switch(chtype)                //check to see if there is a state transition
		   {
		   case lett:
		   case quote:                  //if the type is a letter go to word state
			    WhitetoWord();
				break;
		   case digit:
           case minus:
		   case plus:
			   WhitetoDigit();
			   break;
		   case point:
			   WhitetoDble();
			   break;
		   }

		   if(chtype == endstr)  //leave if ch is end of the string
			   break;
	   }
   }
void ExponentState()
{
	while(state == expon)   //while we are still in exponent state
	   {  
		   ch = line[k++];    //move on to the next char
		   ChartypeHandler(ch);   //get the char type
		   switch(chtype)
		   {
		   case whsp:
			   ExponenttoWhite();   //transition to white state
			   break;
		   }
		   if (chtype == whsp || ch == '\0')
			   break;
		   printf("%c",ch); //print out the char
	   }       

}
void DigitState() 
{
	while(state == num)
	{
		ch = line[k++];  //move on to next char
		ChartypeHandler(ch);//get that char type
		if(toupper(ch) == 'E')//check for exponent while in num state
			chtype=expo;
		switch(chtype)
		{
		case point:
			DigittoDble();//transition into dble state if type is decimal 
			break;
		case whsp:
			DigittoWhite();//transition into white if type is white 
			break;
		case expo:
			DigittoExponent();//transition into exponent if type is exponent
			break;
		}
		if (chtype == digit || chtype == plus || chtype == minus) //print only if the char is a digit or sign
			printf("%c", ch);
		else                   //leave if char is any other type
			break;
	}
}
void WordState()
{
	while (state == word)
	{   ch = line[k++];
		ChartypeHandler(ch);
		
		switch(chtype)            //if there is a space/end of the line
		{
		case whsp:
			WordtoWhite();
			break;
		}
		if (chtype == whsp || chtype == endstr)
			break;//only out put the state apporpiate chars
		else
			printf("%c", ch);

	}
}
void DoubleState()
{
	while(state == dble)
	{   ch = line[k++];
		ChartypeHandler(ch);
		if (towupper(ch) == 'E')
			chtype = expo;
		
		switch (chtype)
		{
		case whsp:
			DbletoWhite();
			break;
		case expo:
			DbletoExponent();
			break;
		}
		if (chtype == digit)   //only output the chars that are digits/numbers
			printf("%c", ch);
		else                  //leave if char is any other type
			break;
	}
}
//---------------------STATE TRANSISSIONS FUNCTIONS---------------------
/*  every function shows the char that caused a state change, what state it's currently in and what state it's going to and then changes the state*/
void WhitetoWord()
{
	printf("\n%cST%d-%d\n",ch,state,word);
	state = word;                          
}
void WhitetoDigit()
{
	printf("\n%cST%d-%d\n", ch, state, num);
	state = num;
}
void WhitetoDble()
{	
	printf("\n%cST%d-%d\n", ch, state, dble);
	state = dble;
}
void WordtoWhite()
{	
	printf("\n%cST%d-%d",ch,state,white);
	state = white;
}
void DigittoWhite()
{	
	printf("\n%cST%d-%d",ch,state,white);
	state = white;
}
void DigittoDble()
{	
	printf("\n%cST%d-%d\n", ch, state, dble);
	state = dble;
}
void DigittoExponent()
{	
	printf("\n%cST%d-%d\n", ch, state, expon);
	state = expon;
}
void DbletoWhite()
{	
	printf("\n%cST%d-%d", ch, state, white);
	state = white;
}
void DbletoExponent()
{	
	printf("\n%cST%d-%d\n", ch, state, expon);
	state = expon;
}
void ExponenttoWhite()
{	
	printf("\n%cST%d-%d",ch,state,white);
	state = white;
}