// twins.cpp
// demonstrates integer arithmetic
// loops the odd integers between a lower and upper limit

#include <iostream>
#include <conio.h>    
#include <iomanip> 
using namespace std;

int main()
{
   int lo, hi, p;

   cout << "This program generates odd numbers between odd limits lo and hi.\n";
   cout << "Type a positive odd integer lower limit lo: \n";
   cin >> lo;
   cout << "Type a positive odd integer upper limit hi >= lo + 2: \n";
   cin >> hi;

   p = lo;
   while( p <= hi )            //until upper limit
      {
      cout << setw(6) << p-2 << setw(6) << p << '\n';
      p = p+2; 
      }                        //end while
   system( "pause");
   return 0;
}  //end main
