/*
Due Date: September 20, 2013
Software Designer: Kombiz Khayami
Course: 420-306-ab section02 
Deliverable: Assignment #1 -- GAP-N Twins (Version 3)
Description: Program will ask the user for an upper limit, lower limt and a GAP-N then print out all the twin prim numbers that are between the 2 limits and n numbers apart 
*/

#include <iostream>    
#include <iomanip> 
using namespace std;

int main()
{ int lo, hi, p, t, f, n, j; // lo is the lower limit, hi is the upper limit, p is any odd number that is going through the loop at any instance, t: indicates if their are more trials, f: indicates if a prime is found or not, n: the gap between the outputed prime numbers, j: indicates whether or not prime number has been encountered (refered to as jumper)

   cout << "This program generates prime twin prime numbers odd numbers between odd limits lo and hi.\n";
   cout << "Type a positive odd integer lower limit lo: \n";
   cin >> lo;
   cout << "Type a positive odd integer upper limit hi >= lo + 2: \n";
   cin >> hi;
   cout <<"Type a positive interger GAP n >= 3: \n";
   cin >> n;

   p = lo;              // starting at the lower limit
   j = 0;               // setting jumper to 0
   while( p <= hi )            //until upper limit
   {t = 3;
	f = 1;
	  while( t * t <= p && f == 1) //while more trials exist and a prime is not found
	  {if(p%t == 0)                //is p prime?
		  {f = t;                //founda a prime
		   t = p;                //end the trials 
		  }
	  else
		 t = t + 2;              // move on to next trial
      }
	if (f == 1)                  //p prim?
	  {if(j==1)                 //did we encounter a prime number before?
		{cout << p-n << "," << p << " are prime twins \n";    //out put the prime twins 
		   j = 0;                                            
		   p = p - n;										 //go back to previous p value 
		   p = p + 2;                                        
		  }
		  else
		  {p = p + n;
		   j = 1;
		  }
	  }
	  else
	  {if(j==1)               //did we encounter a prime number before?
		  {
		   p = p - n;         //jump p back since previous p was not prime
		   j = 0;
		  }

		  p = p + 2;          
	  } 
   }                        //end while
   system( "pause");
   return 0;
}  //end main