/******************************* ID BLOCK *****************************************************
Due Date November 18, 2013
Software Designer : Kombiz Khayami
Course : 420 - 306 - AB Fall 2013
Deliverable: Assignment #4 - State Analysis/Parsing
Description:
		Application process and Parses 4 lines of string data using a finite-state approach.
		A state approach divides the application into a series of states(ie. num, white, word etc).
		The application will go through these different states depending on what character type is
		currently being processed. During processing if a numeric value is encountered application will
		put it into one of 2 arrays. myints which holds integer values and mydbls which holds double values.
		if a word is encountered the length is recorded and its frequency is stored in array mywords.
		Once the text lines are processed the contents of each array along with the appropriate index
	    is outputted to the user in a table format.

/*************************************** PERLIMINARIES *****************************************/
#include <iostream>
#include <iomanip>             //for setw function to format output
#pragma warning(disable:4996);
using namespace std;

enum StateType { white, word, num, dble, expon };//state types
enum CharType { whsp, lett, expo, digit, p, m, point, quote, endstr };//character types
CharType chtype;			//variable to store the type of the current character
StateType state; 			//current state of the application
//**************************************** CONSTANTS **********************************************
const int LMAX = 200;		//maximum number of chars per line 
const int NLINES = 10;		//maximum number of lines
const int myLINES = 4;      // ACTUAL number of text data lines
const int NDBLE = 10;		//maximum number of doubles
const int NINT = 10;		//maximum number of integers
const int WMAX = 15;		//maximum number of characters in a word
//**************************************** GLOBAL VARIABELS ****************************************
char line[200];             //current line being processed
char ch;                    //current character being processed
int length;					//current line length
int ival; 					//value of the current integer
double val; 				//value of the current double
int power;					//the decimal point adjustment for double 
int expval;					//value of the current exponent
int sign;  					//sign of the current number
int esign; 					//the sign of the current exponent
int wlen; 					//length of current word 
int k;   					//subscript indicating present position within the current line
int s;
int d;
int len; 					//length of current line
// ARRAYS FOR RESULTS
int mywords[WMAX];
int myints[NINT];
double mydbls[NDBLE];

//*****************************FUNCTIONS****************************************
void ChartypeHandler(char);     //gets the char type
//--------------STATE HANDLERS-------------------------
void WhiteState();              //Process spaces and end strings. 
void WordState();               //Process everything that isn't a white space.
void DoubleState();             //Process numbers that are after a decimal point
void ExponentState();           //Process numbers and signs after an exponent
void DigitState();              //Process numbers.
//-------------STATE TRANSITIONS-----------------------
//White State Transitions
void WhitetoWord();
void WhitetoDigit();
void WhitetoDble();
//Word State Transition
void WordtoWhite();
//Number State Transitions
void DigittoWhite();
void DigittoDble();
void DigittoExponent();
//Double State Transitions
void DbletoWhite();
void DbletoExponent();
//Exponent State Transition
void ExponenttoWhite();

//*******************************MAIN BLOCK BEGINS****************************************
int main()
{

	//array of text lines i.e. the input data
	char tline[NLINES][LMAX] = {
		"  first 123 and now second -.1234 and you're needing this 123.456 plus one of these +123. too",
		"  ellen's favourites are 123.654E-2 eg exponent-form which can also be -54321E-03 or this +432e2",
		" I'll prefer numbers like fmt1-dec +.1234567e+05 or fmt2-dec -765.3245 or fmt1-int -837465 or ",
		" even fmt2-int -19283746 which make us think of each state's behaviour for +3 or even .3471e7 states ",
	};

	/****************************************************************************
	PRINT OUT THE RAW TEXT LINES
	****************************************************************************/
	printf("TEXT DATA LINES:\n");
	for( int j = 0; j < myLINES; j++ )		//start going through the input data
	{   strcpy(line, tline[j]);				//get the current line
		length = strlen(tline[j]);			//get length of current line 
		printf("\n\n");
		for( k = 0; k < length; )			//start going through the current line
		{   switch (state)					//switches what state we should be in based on state variable.
			{   case white:
						  WhiteState();		//go to white state
						  break;
				case word:
						  WordState();		//go to word state
						  break;
				case num:
						  DigitState();		//go to Digit state
						  break;
				case dble:
						  DoubleState();	//go to double state
						  break;
				case expon:
						  ExponentState();	//go to exponent state
						  break;
			}
			if( chtype == endstr )			//if end of current line reached 
				break;						//move on to the next line
		}
		state = white;						//assume each line begins with white state
		k = -1;							    //start at the beginning of the line
	}
	/****************************************************************************
	PRINT OUT THE ARRAY RESULTS IN A TABLE FORMATE
	****************************************************************************/
	printf("\n\n");
	printf("Parsing Results\n");
	printf("application processed text lines and accumulated statistics on");
	printf("word length frequency, integers, and doubles encountered\n");
	printf("----------------------------------------------\n\n");
	printf("Word Results: Contents of mywords Array\n");
	printf("Array contains the number of words with a certain length\n");
	printf("---------------------------------------\n");
	printf("Word Length        Frequency\n");
	printf("****************************\n");
	for( int v = 0; v < 15; v++ )               		//for every index in mywords array
	{   if( mywords[v] > 0 )							//if index has a value
		{   printf("|%-2d  %22d|\n", v, mywords[v]);	//output both index and value
			printf("****************************\n");
		}
	}
	printf("\n\n");
	printf("Integer Results: Contents of myints Array\n");
	printf("Array contains the integer constants built from ASCII characters\n");
	printf("-----------------------------------------\n");
	printf("Index        Value\n");
	printf("******************\n");
	for( int l = 0; l < s; l++ )						//for every index in myints array
	{   if( myints[l] != 0 )						    //if index has a value
		{   printf("|%d   %12d|\n", l, myints[l]);		//output both index and value
			printf("******************\n");
		}
	}
	printf("\n\n");
	printf("Double Results: Contents of mydbls Array\n");
	printf("Array contains the double constants built from ASCII characters\n");
	printf("----------------------------------------\n");
	printf("Index         Value\n");
	printf("*******************\n");
	for( int u = 0; u < d; u++ ) 						 //for every index in mydbls array
	{   if( mydbls[u] != 0 )                             //if index has a value 
		{   printf("|%-2d   %12.7g|\n", u, mydbls[u]);   //output both index and value
			printf("*******************\n");
		}
	}
	system("PAUSE");
	return 0;
}

/*************************************FUNCTIONS*********************************************/

/***************************************************************************************
							ChartypeHandler FUNCTION DEFINITION
					gets the type of the current char being processed

***************************************************************************************/
void ChartypeHandler(char ch)
{   if (isspace(ch))
		chtype = whsp;  //char type is a space
	else
	if (isalpha(ch))
		if (state == num || state)
			chtype = expo;
	else
		chtype = lett;           //char type is a letter
	else
	if (isdigit(ch))
		chtype = digit;          //char type is a number

	switch (ch)
	{   case '.':
				chtype = point;  //char is a decimal 
				break;
		case '+':
				chtype = p;
				break;
		case '-':
				chtype = m;      //char type is a sign
				break;
		case '\'':
				chtype = quote;  //char is quote 
				break;
		case '\0':
				chtype = endstr; //its the end of the string
				break;
	}
}

//-------------------------------------STATE HANDLERS---------------------------------------------
														
/**************************************************************************************************

							WhiteState FUNCTION DEFINITION
	processes white space characters until a none white space character causes a state transition.
	if no transition occurred it outputs the current char then move to the next char.
	if one has occurred then it calls the one of 3 state transition functions.

***************************************************************************************************/
void WhiteState()
{   while( state == white )   							//while we are still in white state
	{   ch = line[k];									//get the current char
		ChartypeHandler(ch);						    //get the char type
		switch (chtype)								    //check for state transition
		{   case lett:
			case quote:									//start word processing       
					WhitetoWord();						//transition into word state
					break;
			case digit:
			case m:
			case p:										//start integer processing      
					WhitetoDigit();						//transition into white state
					break;
			case point:									//start double processing   
					WhitetoDble();						//transition into double state
					break;
			default:
					printf("%c", ch);					//print out the current char
					k++;								//move on to the next char
		}
	}
}
/*********************************************************************************************************

									ExponentState FUNCTION DEFINITION
			processes sign and digit characters until a white space character causes a state transition.
			if one has occurred then it calls the  state transition functions if no transition occurred it 
			then checks for a negative sign.if found it saves its value under esign as an integer.
			if no transition occurred and negative sign is not found it builds the ASCII charecter into a number, 
			outputs the current char and moves to the next char.

**********************************************************************************************************/
void ExponentState()
{   while( state == expon )								 //while we are still in exponent state
	{   ch = line[k];									 //get the current char
		ChartypeHandler(ch);							 //get that char type
		switch (chtype)									 //check for state transition or sign
		{   case whsp:
		    case endstr:								 //end of exponent  value
					ExponenttoWhite();					 //transition to white state 
					break;
			case m:										 //check for negative sign
					esign = -1;							 //save value of sign
			default:
					printf("%c", ch);					 //print out the char
					if( chtype == digit )				 //only convert digit types
						expval = expval * 10 + (ch - 48);//builds number value from ASCII characters
					k++;								 //move on to the next char
		}
	}
}
/***********************************************************************************************

								DigitState FUNCTION DEFINITION
			processes digit characters until a none digit character causes a state transition.
			if one has occurred it then calls one of 3 state transition functions
			if no transition occurred it then builds the ASCII character into a number, 
			outputs the current char and moves to the next char.

************************************************************************************************/
void DigitState()
{   while( state == num )							     //while we are still in exponent state
	{   ch = line[k];								     //get the current char
		ChartypeHandler(ch);							 //get that char type
		switch (chtype)									 //check for state transition
		{   case point:									 //start of double value
					DigittoDble();						 //transition into dble state
					break;
            case endstr: 
		    case whsp:									 //end of integer value
					DigittoWhite();						 //transition into white state
					break;
			case expo:									 //start of exponent value
					DigittoExponent();					 //transition into exponent state
					break;
			default:
					printf("%c", ch);					 //print out current char
					if( chtype==digit )					 //only convert digits
						ival = ival * 10 + (ch - 48);	 //builds number value from ASCII characters
					k++;								 //move on to the next char
		}
	}
}
/********************************************************************************************

								WordState FUNCTION DEFINITION
			processes all characters until a white space character causes a state transition.
			if one has occurred it then calls THE state transition function.
			if no transition occurred it then outputs the current char, moves to the next char, 
			and increase the length of the current word.

*********************************************************************************************/
void WordState()
{   while( state == word )			 //while we are still in exponent state
	{   ch = line[k];			     //get the current char
		ChartypeHandler(ch);		 //get that char type
		switch (chtype)				 //check for state transition      
		{   case whsp:
			case endstr:             //end of word processing
					WordtoWhite();   //transition into white state 
					break;
			default:
					printf("%c", ch);//print out current char
					k++;			 //move on to the next char
					wlen++;			 //increase length of the current word
		}
	}
}
/*********************************************************************************************

								DoubleState FUNCTION DEFINITION
			processes digit characters until a none digit character causes a state transition.
			if one has occurred it then calls one of 2 state transition functions
			if no transition occurred it then builds the ASCII character into a number,
			adjusts power, outputs the current char and moves to the next char.

**********************************************************************************************/
void DoubleState()
{   while (state == dble)						   //while we are still in double state
	{   ch = line[k];							   //get the current char
		ChartypeHandler(ch);					   //get that char type
		switch (chtype)							   //check for state transition
		{   case whsp:                             
		    case endstr:						   //end of double value
					DbletoWhite();				   //transition into white state 
					break;
			case expo:                             //end of exponent value
					DbletoExponent();			   //transition into exponent state 
					break;
			default:
					printf("%c", ch);			   //print out current char
					if( chtype == digit )		   //only convert digits
					{   val = val * 10 + (ch - 48);//builds ASCII character into double value
						power = power * 10;		   //increase decimal point adjuster by one
					}
					k++;						   //move on to the next char
		}
	}
}

//---------------------STATE TRANSITION FUNCTIONS---------------------

/***************************************************************************************
								WhitetoWord FUNCTION DEFINITION
					transitions application from white state into word sate.
***************************************************************************************/
void WhitetoWord()
{   state = word; //go to word state
	wlen = 0;     //start getting the new word length
}
/***************************************************************************************
								WhitetoDigit FUNCTION DEFINITION
					transitions application from white state into digit sate.
***************************************************************************************/
void WhitetoDigit()
{   sign = (ch == '-') ? -1 : 1;//get sign of new integer value
	ival = 0;					//start integer value
	state = num;				//go to digit state
}
/***************************************************************************************
								WhitetoDble FUNCTION DEFINITION
					transitions application from white state into Double sate.
***************************************************************************************/
void WhitetoDble()
{   val = 0;			//start double value 
	power = 1;			//set location of decimal point
	sign = 1;			//assume sign is positive  
	state = dble;		//go to double state
}
/***************************************************************************************
								WordtoWhite FUNCTION DEFINITION
					transitions application from word state into white sate.
***************************************************************************************/
void WordtoWhite()
{   mywords[wlen]++;	//increase the number of words with current word length
	state = white;		//go to white state
}
/***************************************************************************************
								DigittoWhite FUNCTION DEFINITION
					transitions application from digit state into white sate.
***************************************************************************************/
void DigittoWhite()
{   ival = ival * sign;	//apply sign to current integer value
	myints[s] = ival;	//save current ival in array
	s++;				//start getting next ival
	state = white;		//go to white state
}
/***************************************************************************************
								DigittoDble FUNCTION DEFINITION
					transitions application from Digit state into Double sate.
***************************************************************************************/
void DigittoDble()
{   val = ival;			//convert integer to double for future divisions
	power = 1;			//set location of decimal point
	state = dble;		//go to double state
}
/***************************************************************************************
								DigittoExponent FUNCTION DEFINITION
					transitions application from digit state into exponent sate.
***************************************************************************************/
void DigittoExponent()
{   val = ival*sign;	//apply sign to double value
	expval = 0;			//start exponent value
	esign = 1;			//assume exponent sign is a posative 
	state = expon;		//go to exponent state
}
/***************************************************************************************
								DbletoWhite FUNCTION DEFINITION
					transitions application from double state into white sate.
***************************************************************************************/
void DbletoWhite()
{   val = (val*sign) / power;//compute signed double value
	mydbls[d] = val;		 //save current val in array
	d++;					 //start getting next val
	state = white;			 //go to white state
}
/***************************************************************************************
								DbletoExponent FUNCTION DEFINITION
					transitions application from double state into exponent sate.
***************************************************************************************/
void DbletoExponent()
{   val = (val*sign) / power;//apply sign to val
	expval = 0;				 //reset exponent value 
	esign = 1;				 //current exponent sign is positive 
	state = expon;			 //go to exponent state 
}
/***************************************************************************************
								ExponenttoWhite FUNCTION DEFINITION
					transitions application from exponent state into white sate.
***************************************************************************************/
void ExponenttoWhite()
{   if( esign == 1 )			//if sign is positive
		while( expval-- > 0 )
			val *= 10;          //move the decimal point to the right
	else						//if sign is Negative
		while( expval-- >0 )
			val /= 10;          //move the decimal point to the left
	mydbls[d] = val;			//save current val in array
	d++;						//move on to the next value
	state = white;				//go to white state
}


