// asst4v1.cpp    ALG306 
// parsing, text processing and numeric conversion
// this is an exercise in state-analysis and state-variable application design 
// data is supplied as an array of strings

#include <iostream>
#include <iomanip>             //for setw function to format output
#pragma warning(disable:4996);
using namespace std;

enum StateType { white, word, num, dble, expon };
enum CharType { whsp, lett, expo, digit, p, m, point, quote, endstr };
CharType chtype;
StateType state; //current state of the application
char line[200], ch;
int length;
int ival; //value of the current interger
double val; //value of the current double
int power;
int expval; //value of the current exponent
int sign;  //
int esign; //
int wlen; //lenghth of the word 
int n;   //make n a local variable instead of a global one? would be easier to comment?
int i;
int k; //subscript indicating present position within the current line
int len;

//*************FUNCTIONS*******************
//--------------STATE HANDLERS-------------------------
void WhiteState(); //reads in only white spaces and end strings(end of the line)
void WordState();//reads in everything that isn't a white space
void DoubleState();//reads in only digits that are after a decimal point
void ExponentState();//
void DigitState();//reads in only digits
void ChartypeHandler(char);  //checks what type the char is
int atoint(char[], int);     //converts ascii charecters to intergers
int atodble(char[], int);    //converts ascii charecters to doubles
int atoexpo(char[], int);    //converts ascii charecters to exponents
//-------------STATE TRANSITIONS----------------
//White State Transition
void WhitetoWord();
void WhitetoDigit();
void WhitetoDble();
//Word State Transition
void WordtoWhite();
//Number State Transitions
void DigittoWhite();
void DigittoDble();
void DigittoExponent();
//Double State Transitions
void DbletoWhite();
void DbletoExponent();
//Exponent State Transition
void ExponenttoWhite();

//********************MAIN BLOCK*****************************
int main()
{
	const int LMAX = 200;		//maximum number of chars per line 
	const int NLINES = 10;		//maximum number of lines
	const int myLINES = 4;      // ACTUAL number of text data lines
	const int NDBLE = 10;		//maximum number of doubles
	const int NINT = 10;		//maximum number of integers
	const int WMAX = 10;		//maximum number of characters in a word

	//array of text lines i.e. the input data
	char tline[NLINES][LMAX] = {
		"  first 123 and now second -.1234 and you're needing this 123.456 plus one of these +123. too",
		"  ellen's favourites are 123.654E-2 eg exponent-form which can also be -54321E-03 or this +432e2",
		" I'll prefer numbers like fmt1-dec +.1234567e+05 or fmt2-dec -765.3245 or fmt1-int -837465 or ",
		" even fmt2-int -19283746 which make us think of each state's behaviour for +3 or even .3471e7 states ",
	};

	// ARRAYS FOR RESULTS
	// double mydbls [NDBLE];
	// int myints [NINT];
	// int mywords[WMAX];

	/****************************************************************************
	PRINT OUT THE RAW TEXT LINES
	****************************************************************************/
	cout << "TEXT DATA LINES:" << endl << endl;
	cout << endl;
	for (int j = 0; j<myLINES; j++)  //start going through the input data
	{
		strcpy(line, tline[j]);//get the current line
		length = strlen(tline[j]);//get the length of that line 
		cout << line << endl;//out put the current line
		for (k = 0; k<length;)   // start going through the current line
		{
			switch (state)  //checking what state we should be in 
			{
			case white:     //if state is white 
				WhiteState();//go to white state
				break;
			case word:       //if state is word 
				WordState(); //go to word state
				break;
			case num:        //if state is number 
				DigitState();//go to Digit state
				break;
			case dble:        //if state is double 
				DoubleState();//go to double state
				break;
			case expon:         //if state is exponent 
				ExponentState();//go to exponent state
				break;
			}
			if (chtype == endstr)           //if we have reched the end of the line 
				break;                      //move on to the next line


		}
		state = white;    //assume each line begins with white state
		k = -1;           //go to/start at the begining of the line
		n = 0;            //make n a local variable instead of a global one?
		system("PAUSE");  //pause after each line parsed
		printf("\n\n");
	}
	system("PAUSE");
	return 0;
}

void ChartypeHandler(char ch)
{
	if (isspace(ch))
		chtype = whsp;
	else
	if (isalpha(ch))
		chtype = lett;
	else
	if (isdigit(ch))
		chtype = digit;




	switch (ch)
	{
	case '.':
		chtype = point;
		break;
	case '+':
		chtype = p;
		break;
	case '-':
		chtype = m;
		break;
	case '\'':
		chtype = quote;
		break;
	case '\0':
		chtype = endstr;
		break;
	}
}
void WhiteState()
{
	while (state == white)   //while we are still in white state
	{
		ch = line[k];  //get the current char

		ChartypeHandler(ch);   //get the char type
		switch (chtype)                //check to see if there is a state transition
		{
		case lett:
		case quote:                  //if the type is a letter or quote go to word state
			WhitetoWord();
			break;
		case digit:
		case m:
		case p:                      //if the type is a digit or aign go to digit state
			WhitetoDigit();
			break;
		case point:                  //if the type is a decimal point go to Double state
			WhitetoDble();
			break;
		}

		if (chtype != white || chtype == endstr)  //leave if ch is end of the string or not a white space
			break;
		printf("%c", ch); //print out the current char
		k++;		//move on to the next char
	}
}
void ExponentState()
{
	expval = atoexpo(line, k); // get the value of the expoent 
	while (state == expon)   //while we are still in exponent state
	{
		ch = line[k];    //get the current char
		ChartypeHandler(ch);   //get that char type
		switch (chtype)        //check to see if there is a state transition
		{
		case whsp:
		case endstr:             //if current char is a space or the end of the line
			ExponenttoWhite();   //transition to white state 
			break;
		}
		if (chtype == whsp || ch == '\0')  //leave if ch is end of the string or a white space
			break;
		printf("%c", ch); //print out the char
		k++;              //move on to the next char
	}

}
void DigitState()
{
	ival = atoint(line, k);
	while (state == num)   //while we are still in exponent state
	{
		ch = line[k];  //get the current char
		ChartypeHandler(ch);//get that char type
		if (toupper(ch) == 'E')//check for an exponent while in num state
			chtype = expo;
		switch (chtype)        //check to see if there is a state transition
		{
		case point:
			DigittoDble();//transition into dble state if type is decimal 
			break;
		case whsp:
			DigittoWhite();//transition into white if type is white 
			break;
		case expo:
			DigittoExponent();//transition into exponent if type is exponent
			break;
		}
		if (chtype == digit || chtype == p || chtype == m) //print only if the char is of type digit or sign
			printf("%c", ch);
		else                   //leave if char is any other type
			break;
		k++;   //move on to the next char
	}
}
void WordState()
{
	while (state == word)   //while we are still in exponent state
	{
		ch = line[k];       //get the current char
		ChartypeHandler(ch);//get that char type
		switch (chtype)    //check to see if there is a state transition       
		{
		case whsp:
		case endstr:
			WordtoWhite();   //transition into whiteif there is a space/end of the line
			break;
		}
		if (chtype == whsp || chtype == endstr)
			break;//only out put the state apporpiate chars
		else
			printf("%c", ch);
		k++;  //move on to the next char
		wlen++; //increase lenght of the current word


	}
}
void DoubleState()
{
	val = atodble(line, k);
	while (state == dble)
	{
		ch = line[k];
		ChartypeHandler(ch);
		if (towupper(ch) == 'E')
			chtype = expo;

		switch (chtype)
		{
		case whsp:
			DbletoWhite();
			break;
		case expo:
			DbletoExponent();
			break;
		}
		if (chtype == digit || chtype == point)   //only output the chars that are digits/numbers
			printf("%c", ch);
		else                  //leave if char is any other type
			break;
		k++;
	}
}
//---------------------STATE TRANSISSIONS FUNCTIONS---------------------
/*  every function shows the char that caused a state change, what state it's currently in and what state it's going to and then changes the state*/
void WhitetoWord()
{
	printf("ST%d-%d\n", state, word);
	state = word;
	wlen = 0;
}
void WhitetoDigit()
{
	printf("ST%d-%d\n", state, num);
	ival = 0;
	state = num;
}
void WhitetoDble()
{
	val = 0;
	power = 1;
	sign = 1;
	printf("ST%d-%d\n", state, dble);
	state = dble;
}
void WordtoWhite()
{
	printf("ST%d-%d Word Length: %d\n", state, white, wlen);
	state = white;
}
void DigittoWhite()
{
	printf("ST%d-%d Integer value: %d\n", state, white, ival);
	state = white;
	n = 0;
}
void DigittoDble()
{
	printf("ST%d-%d\n", state, dble);
	val = ival;
	power = 1;
	state = dble;
}
void DigittoExponent()
{
	val = ival;
	expval = 0;
	esign = 1;
	printf("ST%d-%d\n", state, expon);
	state = expon;
}
void DbletoWhite()
{
	val = (val*sign) / power;
	printf("ST%d-%d Double value: %.7g\n", state, white, val);
	state = white;
}
void DbletoExponent()
{
	val = (val*sign) / power;
	expval = 0;
	esign = 1;
	printf("ST%d-%d\n", state, expon);
	state = expon;
}
void ExponenttoWhite()
{
	if (esign == 1)      //if sign is Posiative
	while (expval-- > 0)
		val *= 10;      //move the decimal point to the right
	else                //if sign is Negative
	while (expval-- >0)
		val /= 10;      //move the decimal point to the left
	printf("ST%d-%d Double value: %.7g\n", state, white, val);
	state = white;
}

int atoint(char s[], int i)
{
	sign = (s[i] == '-') ? -1 : 1;
	if (s[i] == '+' || s[i] == '-') //if there is an expliciate sign
		i++;                        //skipt it
	for (n = 0; isdigit(s[i]); i++) //
		n = n * 10 + (s[i] - 48);   //get there numerical value as a character
	return n * sign;
}
int atodble(char s[], int i)
{
	//sign = (s[i] == '-') ? -1 : 1;
	if (s[i] == '.')                  //if there is an expliciate decimal point
		i++;                          //skip it
	for (power = 1; isdigit(s[i]); i++)//
	{
		n = n * 10 + (s[i] - 48);  //get the numerical value as a character
		power = power * 10;        //
	}
	return n;
}
int atoexpo(char s[], int i)
{
	i++;
	esign = (s[i] == '-') ? -1 : 1;
	if (s[i] == '+' || s[i] == '-')  //if there is an expliciate sign
		i++;                         //skipt it
	for (n = 0; s[i] >= 48 && s[i] <= 57; i++)//
		n = n * 10 + (s[i] - 48);  //get the numerical value as a character
	return n;
}
