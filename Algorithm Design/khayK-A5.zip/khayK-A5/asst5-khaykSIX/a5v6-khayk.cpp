/******************************* ID BLOCK *****************************************************
Due Date December 6, 2013
Software Designer : Kombiz Khayami
Course : 420 - 306 - AB Fall 2013
Deliverable: Assignment #5 - Stacks and Expression Evaluation
Description:
		Application reads in a series of infix expressions (ex: A+B ) who�s operands 
		consists of {A, B,C...} and who�s operators consists of {+,-,*,/,$} with '$' being an exponent. 
		Each infix expression is converted to postfix and the postfix is used to calculate its value. 
		Postfix has operators placed after two operands (ex: A+B = AB+). After conversion application
		outputs current infix expression, postfix expression, and value of current postfix.
		The list of available Operands and their corresponding values are also displayed.

/*************************************** PERLIMINARIES *****************************************/
#include <iostream>
#include <iomanip>            
#pragma warning(diable:4996) //for setw function to format output p
#include <math.h>       /* pow */
using namespace std;		   //standard namespace
//**************************************** CONSTANTS *********************************
const int LMAX = 50;        //maximum number of infix strings in array
const int NMAX = 30;        //maximum size of each infix string
const int LSIZE = 5;        //actual number of infix strings in the array infix
const int NUMOPNDS = 10;    //number of different operands i.e. A through J
const int MAXSTACK = 100;   //maximum number of items allowed in the stack structures
//********************** GLOBAL VARIABLES ****************************************
 int IDX;					 //infix array index
 double val;				 //postfix evaluation value 
 char ifx[LMAX];			 //current infix notation being processed
 char pfx[LMAX];		     //postfix notation of current infix expression

//array of infix strings
char infix[LMAX][NMAX] = { "A+B-C",
							"(A+B)*(C-D)", 
	                         "A$B*C-D+E/F/(G+H)",
							 "((A+B)*C-(D-E))$(F+G)", 
					    	 "A-B/(C*D$E)"  };			
  
//arrays for the operands and their values
char opnd[NUMOPNDS] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'};
float opndval[NUMOPNDS] = { 3, 1, 2, 5, 2, 4, -1, 3, 7, 187};

//**********************STRUCTURES****************************************
//structure that contains arithmetic operators that are of data type char
struct OPERATOR_STACK
{   int top;
    char item[MAXSTACK];
};
//structure that contains numeric values of operands that are of data type double
struct OPERAND_STACK
{   int top;
    double item[MAXSTACK];
};

OPERATOR_STACK opstk;
OPERAND_STACK opndstk;
//**********************CONVERSION*******************************************************
/****************************************************************************
						FUNCTIONS
****************************************************************************/
void convert(char[], char[]);					//convert's infix expressions to postfix notation
double eval(char[]);							//evaluates postfix expression 
//**********************OPERANDS****************************************
double pop(OPERAND_STACK&);						//removes items from the stack
void push(OPERAND_STACK&, double);				//puts items on to the stack
//**********************OPERATORS****************************************
char opterpop(OPERATOR_STACK&);					//removes items from the stack
void opterpush(OPERATOR_STACK&, char);			//puts items on to the stack
char optrpopandtest(OPERATOR_STACK&, char&, bool&);	//checks for empty stack  
//**********************CONVERSION***************************************
bool prcd(char, char);					//decides precedence of operators/brackets (based off BEMDAS)
int priority(char&);							//decides operator priority

//*******************************MAIN BLOCK BEGINS****************************************
int main() 
{   //stacks are empty at start
	opndstk.top = -1;
	opstk.top = -1;
	
	double val;										//postfix expression value

	printf("Description\n");
	printf("--------------------------------------------------------\n");
	printf("program converts infix expressions to postfix expression\n");
	printf("and calculates the value of the postfix expression\n\n\n");


	   cout << setw(40) << "OPERANDS AND THEIR VALUES:" << endl << endl;
   for( int j=0; j<NUMOPNDS; j++)
 	   cout << setw(5) << opnd[j];
   cout << endl << endl;
   for( int j=0; j<NUMOPNDS; j++)
	   cout << setw(5) << opndval[opnd[j] - 'A'];
   printf("\n\n\n");
	
   printf("RESULTS:\n\n");	
	cout << "         INFIX EXPRESSION                POSTFIX RESULT                VALUE" << endl;
	printf("         ----------------		 --------------	               -----\n");
   for( IDX = 0; IDX <= LSIZE - 1; IDX++)			//process all infix expressions
   {   strcpy(ifx, infix[IDX]);						//save the current infix expression being converted
	   convert(ifx, pfx);							//convert infix to postfix
	   val = eval(pfx);								//get value of postfix expression
	   cout << setw(25) << ifx << setw(30) <<pfx<< setw(21) << val << endl;//output expressions and value
   }
   printf("\n");
   system("pause");

}

//*******************************FUNCTIONS***********************************

/****************************************************************************
                 CONVERSION FUNCTION DEFINITION 
function processes the current infix expression and converts it to postfix
by adding operators and operands to the postfix expression based on rule BEMDAS
****************************************************************************/
void convert(char s[], char t[])
{   char k;											//current character being processed
	char topsym = ' ';                              //holds top operator popped from stack
	int j = 0;
	bool und = true;								//checks to see if the stack is empty

	for ( int i = 0; i < strlen(s); i++ )			//as long as there are more infix symbols
	{	k = s[i];									//get next infix symbol
		if(isalpha(k))								//if infix symbol is operand 
			t[j++] = k;								//add it to postfix sting
		else										//if infix symbol is operator
		{   optrpopandtest(opstk, topsym, und);     //check if stack is empty and get top operator
			while (!und && prcd(topsym, k))			//stack not empty and previous
													//operator proceeds current operator?
			{   t[j++] = topsym;					//join operator to postfix string
				optrpopandtest(opstk, topsym, und);	//check if stack is empty and get next top operator
			}

			if (!und)								//stack not empty?
				opterpush(opstk, topsym);			//put top operator back onto stack

			if (und || k != ')')					//if stack empty or end of bracket not reached 
				opterpush(opstk, k);				//put current operator onto stack
			else                                    
				topsym = opterpop(opstk);           //remove left over bracket from stack 
		}
	}

	for(opstk.top; opstk.top > -1; opstk.top--)		//pop rest of stack and join it to postfix 
		t[j++] = opstk.item[opstk.top];

	t[j++] ='\0';									//cut off any left over symbols
}

/****************************************************************************
					EVAL FUNCTION DEFINITION
evaluates current postfix expression and returns its value as a double
uses a stack of real numbers to get operand values. 
****************************************************************************/
double eval(char h[])
{
	char s;          //current character being processed
	double op2, op1; //value of the current operands 
	
	for(int i = 0; i<strlen(h);i++)			//process postfix expression
	{   s = h[i];							//get current character
		if(s >= 'A' && s <= 'J')			//if character is operand
			push(opndstk, opndval[s - 'A']);//put its value on operand stack
		else								//character is an operator 
		{   //get value of 2 operands from stack
			op2 = pop(opndstk);
			op1 = pop(opndstk);
			//decides which operation to preform
			switch(s)						
			{   case '+':
					val = op1 + op2;
					break;
				case '-':
					val = op1 - op2;
					break;
				case '/':
					val = op1 / op2;
					break;
				case '*':
					val = op1 * op2;
					break;
				case '$':
					val = pow(op1, op2);
					break;
			}
			push(opndstk, val);				//put value on operand stack
		}
	}
	return val;
}
/*******************OPERAND_STACK FUNCTIONS*********************************/

/****************************************************************************
					push FUNCTION DEFINITION
increases the size of the stack then adds an item to the top of it
****************************************************************************/
void push(OPERAND_STACK &stack, double stuff)
{   stack.top++;				  
	stack.item[stack.top] = stuff;
}
/****************************************************************************
					pop FUNCTION DEFINITION
saves and removes an item from the stack then shrinks the stack by one. 
it then returns the popped item
****************************************************************************/
double pop(OPERAND_STACK &stack)
{   double i;				//item being saved 

	i=stack.item[stack.top]; 
	stack.top--;			 

	return i;				 
}
/*******************OPERATOR_STACK FUNCTIONS********************************/

/****************************************************************************
					opterpush FUNCTION DEFINITION
increases the size of the stack then adds an item to the top of it
****************************************************************************/
void opterpush(OPERATOR_STACK &stack, char stuff)
{	stack.top++;				  
	stack.item[stack.top] = stuff;
}
/****************************************************************************
					opterpop FUNCTION DEFINITION
	saves and removes an item from the stack. it then returns the popped item
****************************************************************************/
char opterpop(OPERATOR_STACK &stack)
{   char i;					  //item being saved 

	i = stack.item[stack.top];
	stack.top--;			  

	return i;			      
}
/****************************************************************************
					optrpopandtest FUNCTION DEFINITION
tests to see if the stack is empty. if not empty it then removes, 
saves the top most item and shrinks the stack. it hen returns the top most item 
from the stack.
****************************************************************************/
char optrpopandtest(OPERATOR_STACK &stack, char &tops, bool &u)
{   if(stack.top <= -1)				 
		u = true;
	else							 
	{	tops = stack.item[stack.top];
		stack.top--;				 
		u = false;			 
	}

	return tops;
}

/*******************CONVERSION FUNCTIONS*********************************/

/****************************************************************************
					prcd FUNCTION DEFINITION
			decides priority of operators based on BEMDAS rule.
			  returns a Boolean which holds the precedence 
****************************************************************************/ 
bool prcd(char left, char right)
{   bool q;

	if(left== '(')//start of bracket operation?
		q = false;
	else 
	if(right == '(')
		q = false;
	else
	if(right == ')')//end of bracket operation?
		q = true;						
	else
	if(left == '$' && right == '$')//exponents do not have priority
		q = false;
	else
	if(priority(left)>=priority(right))	//which operator has priority?
		q = true;
	else
		q = false;

	return q;
}

/****************************************************************************
					Priority FUNCTION DEFINITION
decides which operator has priority based on BEMDAS rules and returns 
its value with 1 being the lowest priority and 3 the highest priority.
****************************************************************************/ 
int priority(char &op)
{   int p; //priority value

	switch(op)
	{   case '+':
		case '-':
			p = 1;
			break;
		case '*':
		case '/':
			p = 2; 
			break;
		case '$':
			p = 3; 
			break;
	}
	return p;
}
