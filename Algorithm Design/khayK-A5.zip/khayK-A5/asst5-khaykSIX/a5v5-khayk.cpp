// asst5v1.cpp       ALGORITHM DESIGN 306  
// arrays of infix strings, postfix strings, operands and operand-values
#include <iostream>
#include <iomanip>            #pragma warning(diable:4996) //for setw function to format output p
#include <math.h>       /* pow */
using namespace std;		   //standard namespace
////**********************GLOBAL VARIABLES****************************************
 const int LMAX = 50;        //maximum number of infix strings in array
 const int NMAX = 30;        //maximum size of each infix string
 const int LSIZE = 5;        //actual number of infix strings in the array infix
 const int NUMOPNDS = 10;    //number of different operands i.e. A through J
 const int MAXSTACK = 100;   //maximum number of items allowed in the stack structures
 int IDX;
 double val;
 char ifx[LMAX];//
 char pfx[LMAX];//
 bool underflow = true;

//array of infix strings
char infix[LMAX][NMAX] = { "A+B-C",
							"(A+B)*(C-D)", 
	                         "A$B*C-D+E/F/(G+H)",
							 "((A+B)*C-(D-E))$(F+G)", 
					    	 "A-B/(C*D$E)"  };			
//array of postfix strings
char postfix[LMAX][NMAX] = { "AB+C-",
							"AB+CD-*", 
	                         "AB$C*D-EF/GH+/+",
							 "AB+C*DE--FG+$", 
					    	 "ABCDE$*/-"  };
  
//arrays for the operands and their values
char opnd[NUMOPNDS] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'};
float opndval[NUMOPNDS] = { 3, 1, 2, 5, 2, 4, -1, 3, 7, 187};

//**********************STRUCTURES****************************************
struct OPERATOR_STACK
{   int top;
    char item[MAXSTACK];
};

struct OPERAND_STACK
{   int top;
    double item[MAXSTACK];
};

OPERATOR_STACK opstk;
OPERAND_STACK opndstk;

/****************************************************************************
						FUNCTIONS
****************************************************************************/
char convert(char[], char[]);
double eval(char[]);
//**********************OPERANDS****************************************
bool empty(OPERAND_STACK);//checks to see if the stack is empty
double pop(OPERAND_STACK&);//removes items from the stack
void dumpstack(OPERAND_STACK);//outputs the contents of the stack
void push(OPERAND_STACK&, double);//puts items on to the stack
//**********************OPERATORS****************************************
bool opterempty(OPERATOR_STACK);//checks to see if the stack is empty
char opterpop(OPERATOR_STACK&);//removes items from the stack
void opterdumpstack(OPERATOR_STACK);//outputs the contents of the stack
void opterpush(OPERATOR_STACK&, char[]);//puts items on to the stack
char optrpopandtest(OPERATOR_STACK&);
int add=0;


int main() 
{
	opndstk.top = -1;
	opstk.top = -1;
	
	double val;

	   cout << setw(40) << "OPERANDS AND THEIR VALUES:" << endl << endl;
   for( int j=0; j<NUMOPNDS; j++)
 	   cout << setw(5) << opnd[j];
   cout << endl << endl;
   for( int j=0; j<NUMOPNDS; j++)
	   cout << setw(5) << opndval[opnd[j] - 'A'];
   printf("\n\n\n");
	
   printf("RESULTS:\n\n");	
	cout << "         INFIX EXPRESSION                POSTFIX RESULT                VALUE" << endl;
	printf("         ----------------		 --------------	               -----\n");
   for(IDX = 0; IDX <= LSIZE - 1; IDX++)
   {
	   strcpy(ifx, infix[IDX]);
	   convert(ifx, pfx);
	   val = eval(pfx);
	   cout << setw(25) << ifx << setw(30) <<pfx<< setw(21) << val << endl;
	   //system("pause");
   }
   printf("\n");


   printf("TESTING CONVERSION STACK\n");
/**************************************************************************** 
					START PUTTING THINGS ON TO THE STACK
****************************************************************************/
   printf("Testing Push:\n");
    opterdumpstack(opstk); //show the stack contents
  for(int i = 0; i < 5; i ++) //add 4 OPERANDS onto the stack
   {
	   opterpush(opstk, pfx);  //adds items on to the stack 
	   opterdumpstack(opstk);
   }
   printf("\n");

/**************************************************************************** 
					START REMOVING THINGS FROM THE STACK
****************************************************************************/
   printf("Testing Pop:\n");

   while(underflow == false)//remove everything from the array
   {
	   opterdumpstack(opstk);//shows the stack contents
	   optrpopandtest(opstk);//removes items from stack
   }
   opterdumpstack(opstk);
   system("pause");
}

//*******************************FUNCTIONS***********************************

/****************************************************************************
                 CONVERSION FUNCTION: INFIX TO POSTFIX NOTATION
****************************************************************************/
char convert(char s[], char t[])
{
	strcpy(t, postfix[IDX]);
	return 0;
}

/****************************************************************************
					eval FUNCTION DEFINITION          
****************************************************************************/
double eval(char h[])
{
	char s;
	double op2;
	double op1;
	

	for(int i = 0; i<strlen(h);i++)
	{   s = h[i];
		if(s >= 'A' && s <= 'J')
		{
			push(opndstk, opndval[s - 'A']);//takes s ASCII value and subtracts it from 'A' ASCII value.
			/*for(int j = 0; j < NUMOPNDS; j++)
			{	if(s == opnd[j])
				{    val = opndval[j];
					 push(opndstk, val);//push(opndstk, opndval[s - 'A'] 
				}
			}*/
		}
		else
		{
			op2 = pop(opndstk);
			op1 = pop(opndstk);
			switch(s)
			{
				case '+':
					val = op1 + op2;
					break;
				case '-':
					val = op1 - op2;
					break;
				case '/':
					val = op1 / op2;
					break;
				case '*':
					val = op1 * op2;
					break;
				case '$':
					val = pow(op1, op2);
					break;
			}

			push(opndstk, val);
		}
	}
	return val;
}
/****************************************************************************
					OPERAND_STACK FUNCTIONS
****************************************************************************/
void dumpstack(OPERAND_STACK stack)
{
	for(stack.top; stack.top > -1; stack.top--)
		printf("%c\n", stack.item[stack.top]);
	printf("\n");
}
void push(OPERAND_STACK &stack, double stuff)
{
	stack.top++;
	stack.item[stack.top] = stuff;
}
double pop(OPERAND_STACK &stack)
{
	double i;
	i=stack.item[stack.top];
	stack.top--;
	return i;
}
bool empty(OPERAND_STACK stk)
{
	if(stk.top==-1)
		return true;
	else
		return false;
}
/****************************************************************************
					OPERATOR_STACK FUNCTIONS
****************************************************************************/
void opterdumpstack(OPERATOR_STACK stack)
{
	cout<<"| ";
	if(underflow == true)
		printf("Stack is empty |");
	for (int i = 0; i <= stack.top; i++)
		cout<< stack.item[i]<<" | ";

	printf("\n");
}
void opterpush(OPERATOR_STACK &stack, char stuff[])
{
	/*if(stack.top == -1)
		emp = true;
	else
		emp = false;*/
	stack.top++;
	stack.item[stack.top] = stuff[stack.top];
	if(stack.top == -1)
		underflow = true;
	else
		underflow = false;

}
char opterpop(OPERATOR_STACK &stack)
{
	char i;
	i = stack.item[stack.top];
	stack.top--;
	return i;
}
char optrpopandtest(OPERATOR_STACK &stack)
{
	char i;

	i = stack.item[stack.top];
	stack.top--;
	underflow = false;

	if(stack.top == -1)
		underflow = true;

	return i;
}
bool opterempty(OPERATOR_STACK stk)
{
	if (stk.top == -1)
		return true;
	else
		return false;
}