// asst5v1.cpp       ALGORITHM DESIGN 306  
// arrays of infix strings, postfix strings, operands and operand-values
#include <iostream>
#include <iomanip>            #pragma warning(diable:4996) //for setw function to format output p
using namespace std;		   //standard namespace
////**********************GLOBAL VARIABLES****************************************
 const int LMAX = 50;        //maximum number of infix strings in array
 const int NMAX = 30;        //maximum size of each infix string
 const int LSIZE = 5;        //actual number of infix strings in the array infix
 const int NUMOPNDS = 10;    //number of different operands i.e. A through J
 const int MAXSTACK = 100;   //maximum number of items allowed in the stack structures
 int IDX;
 double val;
 char ifx[LMAX];
 char pfx[LMAX];

//array of infix strings
char infix[LMAX][NMAX] = { "A+B-C",
							"(A+B)*(C-D)", 
	                         "A$B*C-D+E/F/(G+H)",
							 "((A+B)*C-(D-E))$(F+G)", 
					    	 "A-B/(C*D$E)"  };			
//array of postfix strings
char postfix[LMAX][NMAX] = { "AB+C-",
							"AB+CD-*", 
	                         "AB$C*D-EF/GH+/+",
							 "AB+C*DE--FG+$", 
					    	 "ABCDE$*/-"  };
//**********************STRUCTURES****************************************
struct OPERATOR_STACK
{   int top;
    char item[MAXSTACK];
};

struct OPERAND_STACK
{   int top;
    char item[MAXSTACK];
};

OPERATOR_STACK opstk;
OPERAND_STACK opndstk;

////**********************FUNCTIONS****************************************
char convert(char[], char[]);
double eval(char[]);
bool empty(OPERAND_STACK);//checks to see if the stack is empty
char pop(OPERAND_STACK&);//removes items from the stack
void dumpstack(OPERAND_STACK);//outputs the contents of the stack
void push(OPERAND_STACK&, char[]);//puts items on to the stack
int add=0;


int main() 
{
	opndstk.top = -1;
	opstk.top = -1;
	bool emp = false;

			
   //arrays for the operands and their values
   char opnd[NUMOPNDS] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'};
   float opndval[NUMOPNDS] = { 3, 1, 2, 5, 2, 4, -1, 3, 7, 187};

   cout << "         INFIX EXPRESSION                POSTFIX RESULT                VALUE" << endl << endl;

   for(IDX = 0; IDX <= LSIZE - 1; IDX++)
   {
	   strcpy(ifx, infix[IDX]);
	   convert(ifx, pfx);
	   val = eval(pfx);
	   cout << setw(25) << ifx << setw(30) <<pfx<< setw(21) << val << endl;
   }

   system("pause");
/**************************************************************************** 
					START PUTTING THINGS ON TO THE STACK
****************************************************************************/
   printf("PUSHING\n");
   printf("start putting operands on to the stack,\n");
   printf("showing the contents of the stack every time one is added\n");

   while(opndstk.top<3) //add 4 OPERANDS onto the stack
   {
	   push(opndstk, pfx);  //adds items on to the stack
	   dumpstack(opndstk);  //show the stack contents
	   
   }

   system("pause");
   printf("\n");

/**************************************************************************** 
					START REMOVING THINGS FROM THE STACK
****************************************************************************/
   printf("POPPING\n");
   printf("start removing operands from the stack,\n");
   printf("showing the contents of the stack every time one is removed\n");
   while(!emp)//remove everything from the array
   {
	   pop(opndstk);       //removes items from stack
	   dumpstack(opndstk); //shows the stack contents 
	   emp = empty(opndstk);//check if the stack is empty
   }
   system("pause");
}

//*******************************FUNCTIONS***********************************

/****************************************************************************
                 CONVERSION FUNCTION: INFIX TO POSTFIX NOTATION
****************************************************************************/
char convert(char s[], char t[])
{
	strcpy(t, postfix[IDX]);
	return 0;
}
/****************************************************************************
               FUNCTION TO DISPLAY INFIX AND POSTFIX EXPRESSIONS            
****************************************************************************/
/****************************************************************************
                 FUNCTION TO EVALUATE THE POSTFIX EXPRESSION           
****************************************************************************/
double eval(char h[])
{
	return 187.35;
}

void dumpstack(OPERAND_STACK stack)
{
	for(stack.top; stack.top > -1; stack.top--)
		printf("%c\n", stack.item[stack.top]);
	printf("\n");
}

void push(OPERAND_STACK &stack, char stuff[])
{
	stack.top++;
	stack.item[stack.top] = stuff[stack.top];
}

char pop(OPERAND_STACK &stack)
{
	char i;
	i=stack.item[stack.top];
	stack.top--;
	return i;
}
bool empty(OPERAND_STACK stk)
{
	if(stk.top==-1)
		return true;
	else
		return false;
}