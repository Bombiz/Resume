/* ============================ID BLOCK===========================================

Due Date: October 2end, 2013
Software Designer: Kombiz Khayami
Course: 420-306 Autumn section 0002
Deliverable: Assignment #2: Pythagorean Numbers

Description: program ask's the user to enter a lower bound "l" and upper bound "h" then outputs a list of PYTHAGOREAN numbers
(a number that is a perfect square and the sum of 2 squared whole numbers) between l and h. First it will calculate all of the Pythagorean Candidates(the sum of 2 squares),
check if their between the 2 limits and with them creates a unique ordered array/list "pcan". Then find the Pythagorean Numbers in pcan and uses them to create array "PTHY"  
           
/*=================================PRELIMINARIES====================================*/
#include <iostream>
using namespace std;
#include <conio.h> 
#include <math.h>
#include <iomanip> 

/*=============================FUNCTION PROTOTYPE===================================*/
void MakeList(int&, int, int[]);  // creates array pcan.

/* ============================MAIN BLOCK===========================================*/
int main()
   {
   int m;                    // Determines the number of Pythagorean numbers to be generated on the screen
   int i, j;                 // counters used to generate the array of Pythagorean Candidates(pcan). 
   int c;                    // stores Pythagorean Candidate number.                                      
   int h;                    // upper bound
   int l;                    // lower bound
   int t = -1;               // tracks the index of the array
   int mm; 
   const int MAXSIZE = 50000;// array size
   int pcan[MAXSIZE];        // array of Pythagorean Candidates 
   int PTHY[MAXSIZE];        // array of Pythagorean Numbers
   int pc;                   // used in checking if a number is Pythagorean                              
   int pi = 0;               // array index. used to go through the array  
   double xm;

   cout << "This program generates Pythagorean numbers in a list.\n";
   cout << "Enter size limit:\n";
   cin >> m;
   cout << "Enter lower bound LOW:\n"; 
   cin >> l;
   cout << "Enter upper bound HIGH:\n"; 
   cin >> h;

   xm = m + 1;
   mm = sqrt(xm/2.) +2;
                                                                                 
   for ( i=1; i < mm-1; i++ )                                                      //loop generates Pythagorean Candidate numbers.
	   {for (j= i + 1; j < h; j++)      
		{c = i*i + j*j;                                                            //calculating Pythagorean Candidate     
			if(c<=h && c>=l)                                                       //check if c is between upper and lower boundaries. 
				 MakeList(t, c, pcan);
		}
   } 
                                                                                  
   for(int count = 0; count <= t; count++)                                         //loop finds Pythagorean Numbers and adds them to array PTHY
	   {pc =sqrt((double)pcan[count]);
		   if(pc * pc == pcan[count])                                              //checks if pcan[count] is a Pythagorean Number. 
			   {PTHY[pi] = pcan[count];                                            //add Pythagorean Number to array
				pi++;                                                              // move on to next array element 
			   }  
	   }

   cout<< setw(5) <<"Index"<< setw(15) <<"PYTH[Index]"<<endl;
	 for(int count = 0; count < pi; count++)                                       //loop outputs array PTHY
	   cout<<count<< setw(15) <<PTHY[count]<<endl;                                 //output index of array and array element. 1 pair per line
     
   system( "pause");
   }  //end main
/*================================== FUNCTION =====================================*/
void MakeList(int &tail, int r, int p[])
{
	int q = -1;                                                                     // array index. 
	bool f = false;                                                                 //checks if a spot was found for r or if it's a duplicate                       
	int x = 0;                                                                      //used to shift the array to the right

	while(q < tail && !f)                                                           //while not at the end of the array & we have not found a spot for r.           
	{q++;
		if(r>p[q])                                                                  //is r bigger then current array element? 
		{}                                                                          //move on to next array element
		else
		{f=true;                                                                    //found a possible spot for r                                                   
			if(r==p[q])                                                             //is r already in the array? 
			{}                                                                      //go to the beginning of the while(skip it)
			else
			{x=tail;
				while(x>=q)                                                         //loop shifts array to the right  
				{p[x+1]=p[x];
				 x--;
				}
			 tail++;                                                                //increase array size
			 p[q]=r;                                                                //insert r into array
			}
		}
	}

	if(!f)                                                                          //is r bigger then last array element?
	{tail++;                                                                        //increase array size
	 p[tail]=r;                                                                     //insert r into last element 
	}
}// exit function

