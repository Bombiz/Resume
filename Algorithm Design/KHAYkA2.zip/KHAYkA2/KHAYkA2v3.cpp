// pythVER1.cpp
// works with nested loops, integer arithmetic and arrays 
// generates the upper triangular table beautifully, with columns aligned 
// overflows the screen when m > 798 

void MakeList(int&, int, int[]);

#include <iostream>
using namespace std;
#include <conio.h> 
#include <math.h>
#include <iomanip> 

int main()
   {
   int m;
   int i;
   int j;
   int c;
   int r;
   int h;
   int l;
   int k = -1;
   int mm;
   int P[10000];
   double xm;
   
   cout << "This program generates Pythagorean candidate numbers in a table.\n";
   cout << "Enter size limit:\n";
   cin >> m;
   cout << "Enter high:\n"; 
   cin >> h;
   cout << "Enter low:\n"; 
   cin >> l;

   xm = m + 1;
   mm = sqrt(xm/2.) +2;
   
   for ( i=1; i < mm-1; i++ )        
   {   
	for (j= i + 1; j < h; j++)      
	  {
		  c = i*i + j*j;
		  if(c<=h && c>=l)
		  {
			 
			  MakeList(k, c, P);
		  }
	  }
      
   } 


     
   system( "pause");
   } 

void MakeList(int &tail, int r, int P[])
{
	int q = -1;
	bool f = false;
	int x = 0;



	while(q < tail && !f)
	{
		q = q +1;
		if(r>P[q])
		{}
		else
		{
			f=true;
			if(r==P[q])
			{}
			else
			{
				x=tail;
				while(x>=q)
				{
					P[x+1]=P[x];
					x=x-1;
				}

				tail=tail+1;
				P[q]=r;
			}
		}
	}

	if(!f)
	{
		
		tail=tail+1;
		P[tail]=r;
		
	}

	cout<<"r = "<<  r << " t = " << tail << endl;
	cout<<"q  "<<"  "<<"P[q]"<<endl;
	      

	for(q = 0; q <=tail; q++)
	{
		cout<< q << "     " << P[q] << endl;
	}

	system ("pause");


	
}

